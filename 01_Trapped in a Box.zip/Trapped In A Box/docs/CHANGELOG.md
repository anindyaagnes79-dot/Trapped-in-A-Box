# Trapped-in-A-Box

## feat/main-menu
- feat:add interface
    1. Add a scene for the main menu
    2. Set the scene to default scene
    3. Add Start, Option, and Quit Button
- feat:add option panel
    1. Add a scene for the option panel
    2. Add Audio and Brightness slider
    3. Add a back button
- feat: add main-menu functionality
    1. Add main menu level select and option script
    2. Add quit, option, and start function
    3. Add back function for level select and option